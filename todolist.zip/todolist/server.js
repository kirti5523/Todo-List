const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const port = 3000;

app.use(bodyParser.json());

const tasks = [];

app.post('/add-task', (req, res) => {
  const { task } = req.body;
  if (!task) {
    return res.status(400).json({ error: 'Task cannot be empty' });
  }

  tasks.push({ text: task, completed: false });
  res.json({ success: true });
});

app.get('/get-tasks', (req, res) => {
  res.json({ tasks });
});

app.post('/clear-all-tasks', (req, res) => {
  tasks.length = 0;
  res.json({ success: true });
});

app.post('/clear-completed-tasks', (req, res) => {
  const newTasks = tasks.filter((task) => !task.completed);
  tasks.length = 0;
  tasks.push(...newTasks);
  res.json({ success: true });
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
